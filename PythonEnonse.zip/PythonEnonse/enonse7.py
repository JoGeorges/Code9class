print("\t")
print("\tBonjou, bonswa tout moun,")
print("\tMwen espere ke nou anfòm.")
print("\tEgzèsis sa se enonse 7 la.")
print("\tNou pral afiche endèks premye 'a'.")
struser = input("\t- Rantre yon chenn karaktè: ")
for i in struser:
    if i == "a":
        print("\tRezilta a se: " + str(struser.index("a")) + "\n")
        break
print("\tMèsi dèske w te itilize pwogram sila.\n")