print("\t")
print("\tBonjou, bonswa tout moun,")
print("\tMwen espere ke nou anfòm.")
print("\tEgzèsis sa se enonse 8 la.")
print("\tNou pral afiche total tout endèks 'a',")
print("\t  ki nan yon chenn karaktè.")
struser = input("\t- Rantre yon chenn karaktè: ")
sum = 0
flist = [i for i, j in enumerate (struser) if j == ("a")]
for i in flist:
    sum += i
print("\tRezilta a se: " + str(sum) + "\n")
print("\tMèsi dèske w te itilize pwogram sila.\n")