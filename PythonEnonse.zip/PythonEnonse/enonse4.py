print("\t")
print("\tBonjou, bonswa tout moun,")
print("\tMwen espere ke nou anfòm.")
print("\tEgzèsis sa se enonse 4 la.")
print("\tNou pral rekipere premye lèt chak mo,")
print("\t  epi afiche yon nouvo chenn ak inisyal yo.")
struser = list(input("\t- Rantre yon chenn karaktè: ").split(" "))
pseudo = " "
for i in struser:
    pseudo += i[0]
print("\tRezilta a se:" + str(pseudo) + "\n")
print("\tMèsi dèske w te itilize pwogram sila.\n")