print("\t")
print("\tBonjou, bonswa tout moun,")
print("\tMwen espere ke nou anfòm.")
print("\tEgzèsis sa se enonse 9 la.")
print("\tNou pral afiche endèks tout karaktè 'a' nan yon chenn.")
struser = input("\t- Rantre yon chenn karaktè: ")
flist = [i for i, j in enumerate (struser) if j == ("a")]
print("\tRezilta a se: " + str(flist) + "\n")
print("\tMèsi dèske w te itilize pwogram sila.\n")