def add(nb1, nb2):
    result = nb1 + nb2
    return result
def substract(nb1, nb2):
    result = nb1 - nb2
    return result
def multiply(nb1, nb2):
    result = nb1 * nb2
    return result
def divide(nb1, nb2):
    result = nb1 / nb2
    return result
def exponent(nb1, nb2):
    result = nb1 ** nb2
    return result
def factorial(nb1):
    result = 1
    for i in range(1, nb1+1):
        result *= i
    return result
def square(nb1):
    result = nb1 ** 0.5
    return result