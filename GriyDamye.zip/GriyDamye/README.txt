Bonjou, bonswa tout moun, 

Sit sa reprezante imaj yon jwèt pou konesans ke yon rele damye, li kwe ak pyès nan plizyè kawo, mwen fè sit sila a ak HTML, plis CSS e mwen fè li yon fason pou l responsiv nan tout ekran.
Li parèt nòmal, nan nenpòt ekran aparèy la, epi kawo yo toujou rete kare san defòme.
Mèsi anpil

Jonathan GEORGES
